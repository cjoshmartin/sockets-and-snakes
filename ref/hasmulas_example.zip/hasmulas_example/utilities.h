#ifndef _UTILITIES_H_
#define _UTILITIES_H_

#include "structs.h"

position generateTrophy();

#endif