#ifndef _STRUCTS_H_
#define _STRUCTS_H_

typedef struct Poisition{
	int x;
	int y;
} position;


#endif